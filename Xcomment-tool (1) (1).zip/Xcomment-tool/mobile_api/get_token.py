import logging

import tls_client

headers = {
    'User-Agent': 'TwitterAndroid/10.0.0-release.0 (310000000-r-0) Pixel+4/13 (Google;Pixel+4;google;flame;0;;1;2016)',
    'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAAFXzAwAAAAAAMHCxpeSDG1gLNLghVe8d74hl6k4%3DRUMF4xAQLsbeBhTSRrCiQpJtxoGWeyHrDb5te2jpGskWDFW82F',
    'X-Twitter-Client-Version': '10.0.0-release.0',
    'Accept': 'application/json',
    'X-Twitter-Client': 'TwitterAndroid',
    'System-User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 13; Pixel 4 Build/TP1A.221005.002.B2)',
    'X-Twitter-Client-Language': 'en-US',
    'Cache-Control': 'no-store',
    'X-Twitter-Active-User': 'yes',
    'X-Twitter-Api-Version': '5',
    'Accept-Language': 'en-US',
    'Content-Type': 'application/json',
}


class AuthMethods:

    def __init__(self, proxy=None, user_agent=None):
        self.request = tls_client.Session(client_identifier="okhttp4_android_13", random_tls_extension_order=True)
        self.request.headers = headers
        if user_agent:
            self.request.headers['User-Agent'] = user_agent[0]
            self.request.headers['System-User-Agent'] = user_agent[1]
        if proxy:
            proxy = {
                "http": proxy['http://'],
                "https": proxy['https://']
            }
        self.request.proxies = proxy
        self.request.timeout_seconds = 150
        self.logged_in = False
        self.request.headers['x-guest-token'] = self._get_guest_token()

    def _get_guest_token(self, max_retries=10):
        for retry in range(max_retries):
            response = self.request.post("https://api.twitter.com/1.1/guest/activate.json")

            token = response.json()['guest_token']  # noqa
            return token

        raise ValueError("Guest Token Not Found")

    def sign_in(self, username, password, *, extra=None):
        """
        - This method can be used to sign in to Twitter using username and password
        - It will also check for the saved session for the username in the disk

        :param username: (`str`) Username of the user
        :param password: (`str`) Password of the user
        :param extra: ## NotImplemented
        :return:
        """

        _username = username
        _password = password
        _extra = extra
        return self._login(_username, _password, _extra)

    def _login(self, _username, _password, _extra):
        initial_login_url = "https://api.twitter.com/1.1/onboarding/task.json?flow_name=login&api_version=1&known_device_token=&sim_country_code="
        __login_url = initial_login_url
        __login_flow = FlowData(_username, _password, _extra)
        __login_flow_state = __login_flow.initial_state
        __login_payload = __login_flow.get(__login_flow_state, json_={}, username=_username, password=_password)
        while not self.logged_in:

            response = self.request.post(__login_url, json=__login_payload)
            json_ = response.json()
            print(json_)
            print(response.headers)
            if response.headers.get('Att'):
                self.request.headers['Att'] = response.headers.get('Att')

            if response.json().get('status') == 'success':
                __login_url = __login_url.split("?")[0]
                subtask = response.json()["subtasks"][0].get("subtask_id")

                if subtask == "LoginSuccessSubtask":
                    self.logged_in = True
                    user = json_['subtasks'][0]['open_account']['user']
                    access_token_ = json_['subtasks'][0]['open_account']['oauth_token']
                    access_token_secret = json_['subtasks'][0]['open_account']['oauth_token_secret']
                    return user, access_token_, access_token_secret

                __login_flow_state = subtask

                __login_payload = __login_flow.get(__login_flow_state, _json=json_, username=_username,
                                                   password=_password)
            else:
                raise ValueError(
                    response.text
                )


class FlowData:
    IGNORE_MEMBERS = ['get']

    def __init__(self, _username, _password, extra):
        self._username = _username
        self._password = _password
        self._extra = extra
        self.initial_state = "loginStartFlow"

    def get(self, called_member, **kwargs):
        if called_member is None:
            return self.loginStartFlow(**kwargs)

        for member in dir(self):
            if member not in self.IGNORE_MEMBERS and callable(getattr(self, member)):
                if member == called_member:
                    return getattr(self, member)(**kwargs)

    @staticmethod
    def get_flow_token(_json):
        return _json['flow_token']

    @staticmethod
    def loginStartFlow(**kwargs):
        return {
            "flow_token": None,
            "input_flow_data": {
                "country_code": None,
                "flow_context": {
                    "referrer_context": {
                        "referral_details": "utm_source=google-play&utm_medium=organic",
                        "referrer_url": ""
                    },
                    "start_location": {
                        "location": "deeplink"
                    }
                },
                "requested_variant": None,
                "target_user_id": 0
            },
            "subtask_versions": {
                "action_list": 2,
                "alert_dialog": 1,
                "alert_dialog_suppress_client_events": 1,
                "app_locale_update": 1,
                "check_logged_in_account": 1,
                "choice_selection": 5,
                "contacts_live_sync_permission_prompt": 3,
                "cta": 7,
                "cta_inline": 1,
                "email_verification": 3,
                "end_flow": 1,
                "enter_date": 1,
                "enter_email": 2,
                "enter_password": 5,
                "enter_phone": 2,
                "enter_text": 5,
                "enter_username": 3,
                "fetch_persisted_data": 1,
                "fetch_temporary_password": 1,
                "generic_urt": 3,
                "in_app_notification": 1,
                "js_instrumentation": 1,
                "location_permission_prompt": 2,
                "menu_dialog": 1,
                "notifications_permission_prompt": 4,
                "one_tap": 2,
                "open_account": 2,
                "open_external_link": 1,
                "open_home_timeline": 1,
                "open_link": 1,
                "phone_verification": 5,
                "privacy_options": 1,
                "security_key": 3,
                "select_avatar": 4,
                "select_banner": 2,
                "settings_list": 7,
                "show_code": 1,
                "sign_up": 2,
                "sign_up_review": 5,
                "single_sign_on": 1,
                "standard": 1,
                "topics_selector": 1,
                "tweet_selection_urt": 1,
                "typeahead_search": 1,
                "update_users": 1,
                "upload_media": 1,
                "user_recommendations_list": 4,
                "user_recommendations_urt": 3,
                "wait_spinner": 3,
                "web": 2,
                "web_modal": 2
            }
        }

    def LoginEnterUserIdentifier(self, _json, username, password):
        return {
            "flow_token": self.get_flow_token(_json),
            "subtask_inputs": [
                {
                    "enter_text": {
                        "link": "next_link",
                        "suggestion_id": None,
                        "text": username
                    },
                    "subtask_id": "LoginEnterUserIdentifier",
                }
            ],
            'subtask_versions': {
                'generic_urt': 3,
                'standard': 1,
                'open_home_timeline': 1,
                'app_locale_update': 1,
                'enter_date': 1,
                'email_verification': 3,
                'enter_password': 5,
                'enter_text': 5,
                'one_tap': 2,
                'cta': 7,
                'single_sign_on': 1,
                'fetch_persisted_data': 1,
                'enter_username': 3,
                'web_modal': 2,
                'fetch_temporary_password': 1,
                'menu_dialog': 1,
                'sign_up_review': 5,
                'user_recommendations_urt': 3,
                'in_app_notification': 1,
                'sign_up': 2,
                'typeahead_search': 1,
                'user_recommendations_list': 4,
                'cta_inline': 1,
                'contacts_live_sync_permission_prompt': 3,
                'choice_selection': 5,
                'js_instrumentation': 1,
                'alert_dialog_suppress_client_events': 1,
                'privacy_options': 1,
                'topics_selector': 1,
                'wait_spinner': 3,
                'tweet_selection_urt': 1,
                'end_flow': 1,
                'settings_list': 7,
                'open_external_link': 1,
                'phone_verification': 5,
                'security_key': 3,
                'select_banner': 2,
                'upload_media': 1,
                'web': 2,
                'alert_dialog': 1,
                'open_account': 2,
                'action_list': 2,
                'enter_phone': 2,
                'open_link': 1,
                'show_code': 1,
                'update_users': 1,
                'check_logged_in_account': 1,
                'enter_email': 2,
                'select_avatar': 4,
                'location_permission_prompt': 2,
                'notifications_permission_prompt': 4,
            },
        }

    def LoginEnterPassword(self, _json, username, password):
        return {
            "flow_token": self.get_flow_token(_json),
            "subtask_inputs": [
                {
                    "enter_password": {
                        "link": "next_link",
                        "password": password
                    },
                    "subtask_id": "LoginEnterPassword"
                }
            ],
            "subtask_versions": {
                "action_list": 2,
                "alert_dialog": 1,
                "alert_dialog_suppress_client_events": 1,
                "app_locale_update": 1,
                "check_logged_in_account": 1,
                "choice_selection": 5,
                "contacts_live_sync_permission_prompt": 3,
                "cta": 7,
                "cta_inline": 1,
                "email_verification": 3,
                "end_flow": 1,
                "enter_date": 1,
                "enter_email": 2,
                "enter_password": 5,
                "enter_phone": 2,
                "enter_text": 5,
                "enter_username": 3,
                "fetch_persisted_data": 1,
                "fetch_temporary_password": 1,
                "generic_urt": 3,
                "in_app_notification": 1,
                "js_instrumentation": 1,
                "location_permission_prompt": 2,
                "menu_dialog": 1,
                "notifications_permission_prompt": 4,
                "one_tap": 2,
                "open_account": 2,
                "open_external_link": 1,
                "open_home_timeline": 1,
                "open_link": 1,
                "phone_verification": 5,
                "privacy_options": 1,
                "security_key": 3,
                "select_avatar": 4,
                "select_banner": 2,
                "settings_list": 7,
                "show_code": 1,
                "sign_up": 2,
                "sign_up_review": 5,
                "single_sign_on": 1,
                "standard": 1,
                "topics_selector": 1,
                "tweet_selection_urt": 1,
                "typeahead_search": 1,
                "update_users": 1,
                "upload_media": 1,
                "user_recommendations_list": 4,
                "user_recommendations_urt": 3,
                "wait_spinner": 3,
                "web": 2,
                "web_modal": 2
            }
        }

    def AccountDuplicationCheck(self, _json, username, password):
        return {
            "flow_token": self.get_flow_token(_json),
            "subtask_inputs": [
                {
                    "check_logged_in_account": {
                        "link": "AccountDuplicationCheck_false"
                    },
                    "subtask_id": "AccountDuplicationCheck"
                }
            ],
            "subtask_versions": {
                "action_list": 2,
                "alert_dialog": 1,
                "alert_dialog_suppress_client_events": 1,
                "app_locale_update": 1,
                "check_logged_in_account": 1,
                "choice_selection": 5,
                "contacts_live_sync_permission_prompt": 3,
                "cta": 7,
                "cta_inline": 1,
                "email_verification": 3,
                "end_flow": 1,
                "enter_date": 1,
                "enter_email": 2,
                "enter_password": 5,
                "enter_phone": 2,
                "enter_text": 5,
                "enter_username": 3,
                "fetch_persisted_data": 1,
                "fetch_temporary_password": 1,
                "generic_urt": 3,
                "in_app_notification": 1,
                "js_instrumentation": 1,
                "location_permission_prompt": 2,
                "menu_dialog": 1,
                "notifications_permission_prompt": 4,
                "one_tap": 2,
                "open_account": 2,
                "open_external_link": 1,
                "open_home_timeline": 1,
                "open_link": 1,
                "phone_verification": 5,
                "privacy_options": 1,
                "security_key": 3,
                "select_avatar": 4,
                "select_banner": 2,
                "settings_list": 7,
                "show_code": 1,
                "sign_up": 2,
                "sign_up_review": 5,
                "single_sign_on": 1,
                "standard": 1,
                "topics_selector": 1,
                "tweet_selection_urt": 1,
                "typeahead_search": 1,
                "update_users": 1,
                "upload_media": 1,
                "user_recommendations_list": 4,
                "user_recommendations_urt": 3,
                "wait_spinner": 3,
                "web": 2,
                "web_modal": 2
            }
        }

    def LoginTwoFactorAuthChallenge(self, _json, username, password):
        reason = _json['subtasks'][0]['enter_text']['header']['primary_text']['text']
        print(reason)
        getAlternate = input("> ")

        return {
            "flow_token": self.get_flow_token(_json),
            "subtask_inputs": [
                {
                    "enter_text": {
                        "link": "next_link",
                        "suggestion_id": None,
                        "text": getAlternate
                    },
                    "subtask_id": "LoginTwoFactorAuthChallenge"
                }
            ],
            "subtask_versions": {
                "action_list": 2,
                "alert_dialog": 1,
                "alert_dialog_suppress_client_events": 1,
                "app_locale_update": 1,
                "check_logged_in_account": 1,
                "choice_selection": 5,
                "contacts_live_sync_permission_prompt": 3,
                "cta": 7,
                "cta_inline": 1,
                "email_verification": 3,
                "end_flow": 1,
                "enter_date": 1,
                "enter_email": 2,
                "enter_password": 5,
                "enter_phone": 2,
                "enter_text": 5,
                "enter_username": 3,
                "fetch_persisted_data": 1,
                "fetch_temporary_password": 1,
                "generic_urt": 3,
                "in_app_notification": 1,
                "js_instrumentation": 1,
                "location_permission_prompt": 2,
                "menu_dialog": 1,
                "notifications_permission_prompt": 4,
                "one_tap": 2,
                "open_account": 2,
                "open_external_link": 1,
                "open_home_timeline": 1,
                "open_link": 1,
                "phone_verification": 5,
                "privacy_options": 1,
                "security_key": 3,
                "select_avatar": 4,
                "select_banner": 2,
                "settings_list": 7,
                "show_code": 1,
                "sign_up": 2,
                "sign_up_review": 5,
                "single_sign_on": 1,
                "standard": 1,
                "topics_selector": 1,
                "tweet_selection_urt": 1,
                "typeahead_search": 1,
                "update_users": 1,
                "upload_media": 1,
                "user_recommendations_list": 4,
                "user_recommendations_urt": 3,
                "wait_spinner": 3,
                "web": 2,
                "web_modal": 2
            }
        }

    def LoginAcid(self, _json, username, password):
        reason = _json['subtasks'][0]['enter_text']['header']['secondary_text']['text']
        print(reason)
        getAlternate = input("> ")

        return {
            "flow_token": self.get_flow_token(_json),
            "subtask_inputs": [
                {
                    "enter_text": {
                        "link": "next_link",
                        "suggestion_id": None,
                        "text": getAlternate
                    },
                    "subtask_id": "LoginAcid"
                }
            ],
            "subtask_versions": {
                "action_list": 2,
                "alert_dialog": 1,
                "alert_dialog_suppress_client_events": 1,
                "app_locale_update": 1,
                "check_logged_in_account": 1,
                "choice_selection": 5,
                "contacts_live_sync_permission_prompt": 3,
                "cta": 7,
                "cta_inline": 1,
                "email_verification": 3,
                "end_flow": 1,
                "enter_date": 1,
                "enter_email": 2,
                "enter_password": 5,
                "enter_phone": 2,
                "enter_text": 5,
                "enter_username": 3,
                "fetch_persisted_data": 1,
                "fetch_temporary_password": 1,
                "generic_urt": 3,
                "in_app_notification": 1,
                "js_instrumentation": 1,
                "location_permission_prompt": 2,
                "menu_dialog": 1,
                "notifications_permission_prompt": 4,
                "one_tap": 2,
                "open_account": 2,
                "open_external_link": 1,
                "open_home_timeline": 1,
                "open_link": 1,
                "phone_verification": 5,
                "privacy_options": 1,
                "security_key": 3,
                "select_avatar": 4,
                "select_banner": 2,
                "settings_list": 7,
                "show_code": 1,
                "sign_up": 2,
                "sign_up_review": 5,
                "single_sign_on": 1,
                "standard": 1,
                "topics_selector": 1,
                "tweet_selection_urt": 1,
                "typeahead_search": 1,
                "update_users": 1,
                "upload_media": 1,
                "user_recommendations_list": 4,
                "user_recommendations_urt": 3,
                "wait_spinner": 3,
                "web": 2,
                "web_modal": 2
            }
        }

