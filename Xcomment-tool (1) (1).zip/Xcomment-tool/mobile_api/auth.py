import glob
import json
import os.path
import random
import time
import requests
from tweety.utils import find_objects
from requests_oauthlib import OAuth1
from requests_toolbelt import MultipartEncoder, MultipartEncoderMonitor
from tweety.utils import calculate_md5, check_if_file_is_image, get_random_string
from tweety.types import User
from .get_token import AuthMethods, headers

USER_AGENT_STRING = "TwitterAndroid/10.8.0-release.0 (310080000-r-0) {model}/{android_version} ({manufacturer};{model};{manufacturer};{codename};0;;1;2016)"
USER_AGENT_STRING2 = "Dalvik/2.1.0 (Linux; U; Android {android_version}; {model} Build/TP1A.221005.002.B2)"
path = os.path.dirname(__file__)
build_file = os.path.join(path, "builds.txt")
USER_AGENTS = []
with open(build_file, "r", encoding="utf8") as f:
    lines = f.readlines()
    for line in lines:
        _line_ = line.strip()
        try:
            manufacturer, model, codename, android_version = _line_.split(";")
        except:
            manufacturer, model, codename = _line_.split(";")
            android_version = 13
        USER_AGENTS.append(
            (
                USER_AGENT_STRING.format(manufacturer=manufacturer, model=model, codename=codename.lower(),
                                         android_version=android_version),
                USER_AGENT_STRING2.format(model=model, android_version=android_version)
            )
        )


class MobileApi:
    settings_full = {
        'InNetworkRecommendationsSetting': 'on',
        'SpacesSetting': 'on',
        'LikesVitSetting': 'verified',
        'TopicsSetting': 'on',
        'FollowersVitSetting': 'tailored',
        'TweetsSetting': 'on',
        'RecommendationsSetting': 'on',
        'NewsSetting': 'on',
        'PhotoTagsSetting': 'on',
        'RetweetsSetting': 'anyone',
        'LifelineAlertsSetting': 'on',
        'MomentsSetting': 'on',
        'DirectMessagesSetting': 'on',
        'MentionsSetting': 'anyone',
        'AddressbookSetting': 'on',
        'LikesNonVitSetting': 'anyone',
        'LiveVideoSetting': 'on',
        'FollowersNonVitSetting': 'on',
        'DmReactionSetting': 'reaction_everyone',
        'AdsSetting': 'on',
        'FirstLookSetting': 'on'}

    headers = {
        'timezone': 'Asia/Karachi',
        'os-security-patch-level': '2022-10-05',
        'optimize-body': 'true',
        'accept': 'application/json',
        'x-twitter-client': 'TwitterAndroid',
        'x-twitter-client-language': 'en-US',
        'x-client-uuid': 'c2f22719-b720-4e5e-b61b-3a02dfffcee6',
        'x-twitter-client-deviceid': 'ab0e1d74b2c70bc3',
        'x-twitter-client-version': '10.8.0-release.0',
        'cache-control': 'no-store',
        'x-twitter-active-user': 'yes',
        'x-twitter-api-version': '5',
        'kdt': '0yFzG1sGwo9okIa9j4VThuYpRRYtptU01UlDKCjk',
        'x-b3-traceid': '8da38cf0bb5cea8f',
        'accept-language': 'en-US',
        'content-type': 'application/json',
    }

    SESSION_FILE_EXTENSION = "tw_mobile_session"
    CLIENT_ID = "3nVuSoBZnx6U4vzUxf5w"
    CLIENT_SECRET = "Bcs59EFbbsdF6Sl9Ng71smgStWEGwXXKSjYvPVt7qys"

    def __init__(self, username, password, proxy=None):
        self._username = username
        self._password = password
        self._proxy = proxy
        self.client = requests.Session()
        self.user_agent = random.choice(USER_AGENTS)

        self.user, self.access_token, self.access_token_secret = self.login()
        self.me = Me(self.user)
        self.fcm = None
        self.persistent_id_filename = ""
        self.received_persistent_ids = []
        self.thread = None
        self.thread_timeout = None
        self.auth = OAuth1(
            client_key=self.CLIENT_ID, client_secret=self.CLIENT_SECRET,
            resource_owner_key=self.access_token,
            resource_owner_secret=self.access_token_secret
        )
        new_headers = self.headers
        new_headers['user-agent'] = self.user_agent[0]
        new_headers['system-user-agent'] = self.user_agent[1]
        self.client.headers = new_headers
        self.client.auth = self.auth
        self.client.proxies = self._proxy

    @property
    def proxy(self):
        return self._proxy

    def login(self):
        path = os.path.join("sessions", f"{self._username}.{self.SESSION_FILE_EXTENSION}")
        path = os.path.abspath(path)
        if not os.path.exists(path):
            user, access_token, token_secret = AuthMethods(self._proxy, self.user_agent).sign_in(self._username,
                                                                                                 self._password)
        else:
            user, access_token, token_secret = self._get_from_file(path)
        self._save_to_file(path, user, access_token, token_secret)

        return user, access_token, token_secret

    @staticmethod
    def _save_to_file(path, user, access_token, token_secret):
        with open(path, "w") as f:
            data = {
                "user": user,
                "access_token": access_token,
                "token_secret": token_secret
            }
            json.dump(data, f, indent=4)

    @staticmethod
    def _get_from_file(_path_):
        with open(_path_, "r") as f2:
            data = json.load(f2)
            return data['user'], data['access_token'], data['token_secret']

    def create_tweet(self, text, media=None, reply_to=None):
        URL = "https://na.albtls.t.co/graphql/f4fzP-emDqiJatuGuzfApg/CreateTweet"
        features = {"longform_notetweets_inline_media_enabled": True, "super_follow_badge_privacy_enabled": True,
                    "longform_notetweets_rich_text_read_enabled": True, "super_follow_user_api_enabled": True,
                    "super_follow_tweet_api_enabled": True, "hidden_profile_likes_enabled": False,
                    "hidden_profile_subscriptions_enabled": False,
                    "android_graphql_skip_api_media_color_palette": True,
                    "creator_subscriptions_tweet_preview_api_enabled": True,
                    "freedom_of_speech_not_reach_fetch_enabled": True,
                    "tweetypie_unmention_optimization_enabled": True, "longform_notetweets_consumption_enabled": True,
                    "subscriptions_verification_info_enabled": True, "blue_business_profile_image_shape_enabled": True,
                    "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
                    "super_follow_exclusive_tweet_notifications_enabled": True}
        variables = {"nullcast": False, "includeTweetImpression": True, "includeHasBirdwatchNotes": False,
                     "includeEditPerspective": False, "includeEditControl": True,
                     "includeCommunityTweetRelationship": False, "includeTweetVisibilityNudge": True,
                     "tweet_text": text}

        if reply_to:
            variables['reply'] = {"exclude_reply_user_ids": [], "in_reply_to_tweet_id": reply_to}

        if media:
            variables['media'] = {
                "media_entities": [
                    {
                        "media_id": UploadedMedia(media, self.client).new_upload(),
                        "tagged_users": [],
                    }
                ],
                "possibly_sensitive": False
            }
        json_data = {
            "features": features,
            "variables": variables
        }
        self.client.headers = headers
        tweet = self.client.post(URL, json=json_data).json()
        return find_objects(tweet, 'rest_id', None, recursive=False)

    def set_notifications(self, fcm_token):
        json_data = {
            'user_id': 123,
            'client_application_id': 258901,
            'push_device_info': {
                'udid': 'ab0e1d74b2c70bc3',
                'token': fcm_token,
                'locale': 'en_US',
                'env': 3,
                'checksum': '8b07eb41b07980f476ed876cab9b3e69',
                'protocol_version': 20,
                'os_version': '33',
                'settings': self.settings_full,
            },
        }
        user_id = str(self.access_token).split("-")[0]
        json_data['user_id'] = int(user_id)
        response = self.client.post(
            'https://api.twitter.com/1.1/notifications/settings/login.json',
            json=json_data,
        )
        return response.json()

    def get_notification_enabled_users(self, cursor):
        params = {
            'type': 'sms,live',
            'include_user_entities': 'true',
            'include_profile_interstitial_type': 'true',
            'include_ext_professional': 'true',
            'include_viewer_quick_promote_eligibility': 'true',
            'include_ext_has_nft_avatar': 'true',
            'include_ext_is_blue_verified': 'true',
            'include_ext_verified_type': 'true',
            'include_ext_profile_image_shape': 'true',
            'include_ext_is_tweet_translatable': 'true',
            'user_id': '0',
            'cursor': str(cursor),
        }
        user_id = str(self.access_token).split("-")[0]
        params['user_id'] = str(user_id)
        response = self.client.get('https://api.twitter.com/1.1/friends/list.json', params=params)
        data = response.json()
        users = []
        for user in data['users']:
            user['__typename'] = "User"
            users.append(User(user, None))
        return users, data['next_cursor']

    def enable_notifications(self, user_id):
        data = {
            'user_id': str(user_id),
            'device': 'true',
            'live': 'false',
            'space_device_following': 'false',
        }

        response = self.client.post('https://api.twitter.com/1.1/friendships/update.json', params=data)
        return response.json()

    def follow_user(self, user_id):
        data = {
            'ext': 'mediaRestrictions,altText,mediaStats,mediaColor,info360,highlightedLabel,hasNftAvatar,unmentionInfo,editControl,previousCounts,limitedActionResults,superFollowMetadata',
            'send_error_codes': 'true',
            'user_id': str(user_id),
            'handles_challenges': '1',
        }

        response = self.client.post('https://api.twitter.com/1.1/friendships/create.json', params=data)
        return response.json()


class UploadedMedia:
    URL = "https://upload.twitter.com/1.1/media/upload.json"
    FILE_CHUNK_SIZE = 2 * 1024 * 1024  # 2 mb

    def __init__(self, file_path, client: requests.Session, alt_text=None, sensitive_media_warning=None,
                 media_category="tweet_image"):
        self.media_id = None
        self._file = file_path
        self._client = client
        self._alt_text = alt_text
        self._sensitive_media_warning = sensitive_media_warning if sensitive_media_warning else []
        self.mime_type = self.get_mime_type()
        self.md5_hash = calculate_md5(self._file)

    def get_mime_type(self):
        return check_if_file_is_image(self._file)

    @staticmethod
    def _create_boundary():
        return bytes(f'----WebKitFormBoundary{get_random_string(16)}', "utf-8")

    @staticmethod
    def my_callback(monitor):
        # Your callback function
        print(monitor)

    def new_upload(self):
        params = {
            'original_md5': self.md5_hash
        }
        data = MultipartEncoder(
            fields={'media': (
            "".join(self._file.split(".")[:-1]), open(self._file, "rb"), f"{self.mime_type}; charset=UTF-8")},
            boundary="twitter"
        )
        MultipartEncoderMonitor(data, self.my_callback)
        new_headers = self._client.headers
        new_headers.update({"content-type": data.content_type})
        response = self._client.post(self.URL, data=data, headers=new_headers, params=params).json()
        print(response)
        return response['media_id_string']


class Me:
    def __init__(self, user_data):
        self._raw = user_data
        self.id = self._raw.get('id')
        self.username = self._raw.get('screen_name')
        self.name = self._raw.get('name')

    def __repr__(self):
        return "Me(id={}, username={}, name={})".format(
            self.id, self.username, self.name
        )
