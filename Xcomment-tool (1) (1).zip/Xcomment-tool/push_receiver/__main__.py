from .push_receiver import *

if __name__ == "__main__":
  run_example()
