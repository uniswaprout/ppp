import traceback

from mobile_api.auth import MobileApi

users = [i.strip() for i in open("tokens.txt", "r").readlines() if not str(i).startswith("#")]
for user in users:
    proxy = None
    credentials = user.split("||")
    user_token = credentials[0].replace("L;", "").replace("L2;", "").replace("C2;", "")
    if len(credentials) == 2:
        proxy_str = credentials[1]
        if "@" not in proxy_str:
            proxy_split = proxy_str.split(":")
            proxy_str = f"{proxy_split[0]}:{proxy_split[1]}@{proxy_split[2]}:{proxy_split[3]}"

        proxy = dict.fromkeys(["http://", "https://"], f"http://{proxy_str}")
    try:
        if ":" in user_token:
            username, password = user_token.split(":")
            print(f"[Twitter] Logging in as {username}")
            client = MobileApi(username, password, proxy)
            print(f"\r[Twitter] [Logged In] [Client] {client.me.username} (ID={client.me.id})")
    except Exception as e2:
        traceback.print_exc()
        print(f"\r[Twitter] [Network Error] [{user_token}] {str(e2)}")
