import datetime
import json
import os
import random
from push_receiver import register
from tweety import Twitter, exceptions_ as tweety_errors
from mobile_api.auth import MobileApi
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding


CACHE = dict(clients=[], clients_reply_comment=[], reply_own_comment_token=[], cache=[], listeners=[], likers=[],
             commenters=[])
TWITTER_SENDER_ID = 49625052041
PERSISTENT_ID_FILENAME = "persistent_ids.txt"
KEY = b'9c6d6f3b6c5ac0b56aded3d793649080'


def encrypt_string_and_save(data, output_file, key):
    if isinstance(data, dict):
        data = str(data).replace("'", '"')

    data_bytes = data.encode('utf-8')
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded_data = padder.update(data_bytes) + padder.finalize()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
    with open(output_file, 'wb') as file_out:
        file_out.write(iv)
        file_out.write(encrypted_data)


def decrypt_file_and_get_string(input_file, key):
    with open(input_file, 'rb') as file_in:
        iv = file_in.read(16)
        encrypted_data = file_in.read()

    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())

    decryptor = cipher.decryptor()
    decrypted_data = decryptor.update(encrypted_data) + decryptor.finalize()
    unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
    unpadded_data = unpadder.update(decrypted_data) + unpadder.finalize()

    return unpadded_data.decode('utf-8')


def create_client(token, SESSIONS_DIRECTORY):
    proxy = None
    credentials = [i for i in token.split("|") if i.strip()]
    user_token = "".join(credentials[0].split(";")[1:])
    if len(credentials) == 2:
        proxy_str = credentials[1]
        if "@" not in proxy_str:
            proxy_split = proxy_str.split(":")
            proxy_str = f"{proxy_split[0]}:{proxy_split[1]}@{proxy_split[2]}:{proxy_split[3]}"

        proxy = {"http://": f"http://{proxy_str}", "https://": f"http://{proxy_str}"}

    try:
        if ":" in user_token:
            username, password = user_token.split(":")
            client = MobileApi(username, password, proxy)
        else:
            client = Twitter(os.path.join(SESSIONS_DIRECTORY, f"{user_token}"), proxy=proxy)
            client.connect()

            if not client.me:
                client.load_auth_token(user_token)

        if "L;" in credentials[0]:
            CACHE['listeners'].append(client)
            print(f"\r[Twitter] [Logged In] [Listener] {client.me.username} (ID={client.me.id})")
        elif "L2;" in credentials[0]:
            CACHE['likers'].append(client)
            print(f"\r[Twitter] [Logged In] [Liker] {client.me.username} (ID={client.me.id})")
        elif "C2;" in credentials[0]:
            CACHE['commenters'].append(client)
            print(f"\r[Twitter] [Logged In] [Comment Scanner] {client.me.username} (ID={client.me.id})")
        elif "C3;" in credentials[0]:
            CACHE['clients_reply_comment'].append(client)
            print(f"\r[Twitter] [Logged In] [Comment reply Client] {client.me.username} (ID={client.me.id})")
        elif "C4;" in credentials[0]:
            CACHE['reply_own_comment_token'].append(client)
            print(f"\r[Twitter] [Logged In] [Own Comment reply Client] {client.me.username} (ID={client.me.id})")
        else:
            client_index = int(credentials[0].split(";")[0])
            CACHE['clients'].insert(client_index, client)
            print(f"\r[Twitter] [Logged In] [Client] {client.me.username} (ID={client.me.id})")
    except (tweety_errors.UnknownError, tweety_errors.DeniedLogin, KeyError) as e:
        print(f"\r[Twitter] [LoginDenied] [{user_token}] {str(e)}")
    except Exception as e2:
        print(f"\r[Twitter] [Network Error] [{user_token}] {str(e2)}")


def get_or_create_list(client: Twitter, list_name, list_id):
    results = []
    for i in list_id:
        try:
            results.append(client.get_list(i))
        except:
            pass

        all_lists = client.get_lists()
        for _list in all_lists:
            if str(_list.id) == str(i):
                results.append(_list)

        results.append(client.create_list(list_name))
    return results


def resolve_scanner_time(clients, hours):
    new_clients = {}
    current_time = datetime.datetime.now().timestamp()
    to_add = int(hours)
    new_time = current_time + to_add
    for client in clients:
        new_clients[int(new_time)] = client
        new_time += to_add

    return new_clients


def get_scanner(scanners):
    current_time = datetime.datetime.now().timestamp()
    for k, v in scanners.items():
        if int(k) >= int(current_time):
            return v

    return None


def get_client_comment(client_index):
    comment_file_name = f"comments{client_index + 1}.txt"
    if os.path.isfile(comment_file_name):
        print(f"[System] {comment_file_name} File Found")
        return [i.replace('\\n', '\n').split("|") for i in
                open(comment_file_name, "r", encoding="utf-8", errors="ignore").readlines()]
    return None


def get_client_index(clients, client):
    for index, _client in enumerate(clients):
        if str(client.me.id) == str(_client.me.id):
            return index
    return None


def get_fcm_credentials(username, filename="fcm.creds"):
    filename = filename if not username else f"{username}.{filename}"

    filename = os.path.join("sessions", filename)
    if not os.path.exists(filename):
        print(f"[FCM] [{username}] Registering", end="")
        credentials = register(sender_id=TWITTER_SENDER_ID)
        encrypt_string_and_save(credentials, filename, KEY)

    print(f"\r[FCM] [{username}] Registration Completed")
    data = decrypt_file_and_get_string(filename, KEY)
    data = json.loads(data)
    return data


def get_persistent_id(filename=PERSISTENT_ID_FILENAME):
    filename = os.path.join("sessions", filename)

    if not os.path.exists(filename):
        file = open(filename, "w")
        file.close()

    with open(filename, "r") as f:
        return [str(x).strip() for x in f]


def save_persistent_id(data, filename=PERSISTENT_ID_FILENAME):
    filename = os.path.join("sessions", filename)
    with open(filename, "a") as f3:
        f3.write(f"{data}\n")


def get_current_time(timestamp=False):
    _time_ = datetime.datetime.now()

    if timestamp:
        return int(_time_.timestamp())
    return _time_
