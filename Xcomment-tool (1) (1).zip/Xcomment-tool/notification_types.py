import glob
import os.path
from tweety.utils import parse_time

class Notification:
    def __init__(self, _raw):
        self.impression_id = _raw.get('impression_id')
        self.ticker = _raw.get('ticker')
        self.channel = _raw.get('channel')
        self.type = _raw.get('type')
        self.title = _raw.get('title') or _raw.get('ticker')
        self.uri = _raw.get('uri')
        self.scribe_target = _raw.get('scribe_target')
        self.small_icon = _raw.get('small_icon')

    def get_user(self):
        sender = self._users.get('sender')
        recipient = self._users.get('recipient')
        if sender:
            sender = User(sender)

        if recipient:
            recipient = User(recipient)

        return sender, recipient

class NewTweet(Notification):
    def __init__(self, tweet):
        super().__init__(tweet)
        self._raw = tweet
        self._tweet = eval(self._raw.get('tweet').replace("false", "False").replace("true", "True"))
        self._users = eval(self._raw.get('users').replace("false", "False").replace("true", "True"))
        self.sender, self.recipient = self.get_user()
        self.author = self.sender
        self.tweet = Tweet(self._tweet)

    def __repr__(self):
        return "NewTweet(from={}, tweet={})".format(
            self.sender, self.tweet
        )

class Tweet:
    def __init__(self, tweet):
        self._raw = tweet
        self._notification_images = self._raw.get('notification_images', {})
        self.mention_entities = self._raw.get('mention_entities')
        self.image_url = self._raw.get('image_url')
        self.possibly_sensitive = self._raw.get('possibly_sensitive')
        self.mentions = self._raw.get('mentions')
        self.created_at = self.date = parse_time(self._raw.get('created_at'))
        self.id = self._raw.get('id')
        self.text = self._raw.get('text')
        self.text = self._raw.get('text')
        self.image = self._notification_images.get('expanded_large_image', {}).get('image_url')


    def __repr__(self):
        return "Tweet(id={}, created_at={}, text={})".format(
            self.id, self.date, self.text
        )

class User:
    def __init__(self, user):
        self._raw = user
        self.name = self._raw.get('full_name')
        self.protected = self._raw.get('protected')
        self.screen_name = self.username = self._raw.get('screen_name')
        self.following = self._raw.get('following')
        self.bio = self._raw.get('bio')
        self.profile_image_url = self._raw.get('profile_image_url')
        self.id = self._raw.get('id')

    def __repr__(self):
        return "User(name={}, username={}, id={})".format(
            self.name, self.username, self.id
        )

class Message:
    def __init__(self, message, users):
        self._raw = message.get('message')
        self._users = users
        self._message_data = self._raw.get('message_data', {})
        self.id = self._raw.get('id')
        self.time = self.date = parse_time(self._raw.get('time'))
        self.request_id = self._raw.get('request_id')
        self.conversation_id = self._raw.get('conversation_id')
        self.recipient_id = self._message_data.get('recipient_id')
        self.sender_id = self._message_data.get('sender_id')
        self.sender, self.recipient = self._get_users(self.sender_id), self._get_users(self.recipient_id)
        self.text = self._message_data.get('text')
        self.media = [Media(i) for i in self._message_data.get('attachment', {}).values()]

    def _get_users(self, user_id):
        for user in self._users:
            if str(user_id) == str(user.id):
                return user
        return None

    def __repr__(self):
        return "Message(id={}, date={} sender={}, recipient={}, text={})".format(
            self.id, self.date, self.sender, self.recipient, self.text
        )

class Media:
    def __init__(self, media):
        self._raw = media
        self.type = self._raw.get('type')
        self.id = self._raw.get('id')
        self.media_url = self._raw.get('media_url')
        self.media_url_https = self._raw.get('media_url_https')
        self.url = self._raw.get('url')
        self.audio_only = self._raw.get('audio_only')
        self.original_info = self._raw.get('original_info')

    def __repr__(self):
        return "Media(id={}, type={}, url={})".format(
            self.id, self.type, self.url
        )


class GetNotification:
    KEYS = {
        NewTweet: ["tweet_notifications", "74"]
    }

    def from_json(self, notification):
        notification = eval(notification) if not isinstance(notification, dict) else notification

        notification = notification['data'] if notification.get('data') else notification
        channel = notification.get('channel')
        type_ = notification.get('type')
        result = self._get_type(channel, type_)

        if not result:
            return None

        return result(notification)

    def _get_type(self, _channel_, _type_):
        for key, value in self.KEYS.items():
            if str(_channel_) == str(value[0]) and str(_type_) == str(value[1]):
                return key
        return None