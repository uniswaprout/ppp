import time

from app_new import listener_func, CACHE, on_notification, get_timeout_time
import utils
import multiprocessing

if __name__ == "__main__":

    for index, listener in enumerate(CACHE['listeners']):
        creds = utils.get_fcm_credentials(listener.me.username)
        CACHE['listeners'][index].fcm = creds
        CACHE['listeners'][index].persistent_id_filename = f"{listener.me.username}.{utils.PERSISTENT_ID_FILENAME}"
        CACHE['listeners'][index].received_persistent_ids = utils.get_persistent_id(CACHE['listeners'][index].persistent_id_filename)
        fcm_token = creds["fcm"]["token"]
        response = listener.set_notifications(fcm_token)
        print(f"[Twitter] [{listener.me.username}] Registration Response : {response}")

    try:
        while True:

            for index, listener in enumerate(CACHE['listeners']):
                if not listener.thread or not listener.thread.is_alive():
                    print(f"[System] Starting listener for {listener.me.username}")
                    t = multiprocessing.Process(target=listener_func, args=(listener.fcm, on_notification, listener.received_persistent_ids))
                    CACHE['listeners'][index].thread, CACHE['listeners'][index].thread_timeout = t, get_timeout_time()
                    t.daemon = True
                    t.start()
                    print("[Twitter] Waiting for New Tweet\n--> Press Ctrl+C to Exit")

                elif utils.get_current_time(True) >= listener.thread_timeout:
                    print(f"[System] Listener Thread Timed out for {listener.me.username}, Terminating")
                    CACHE['listeners'][index].thread.terminate()
                    CACHE['listeners'][index].thread_timeout, CACHE['listeners'][index].thread = None, None
            time.sleep(1)

    except KeyboardInterrupt:
        print("\r[System] Exiting..")