import concurrent
import datetime
import json
import multiprocessing
import os.path
import random
import re
import sys
import threading
import time
import traceback
import tweety.exceptions_
import utils
from tweety import Twitter

from notification_types import GetNotification, NewTweet
from push_receiver import register, listen

IMAGES_DIRECTORY = "images"
comments_done = []
SESSIONS_DIRECTORY = "sessions"
LIKERS = 0
LAST_LISTENER = 0
LAST_CLIENT = -1
CURSOR = None
LIST_NAME = "IMPORTANT"
LIST_ID = ["1706312979648491920", "1706306138143105078"]
WRITER_CLIENTS = 0
CLIENTS_LAST_TWEET = {}
COMMENT_ON_OWN_REPLY_CLIENTS_COUNT = 0
COMMENTS = [i.replace('\\n', '\n').split("|") for i in open("comments.txt", "r").readlines()]
user_ids = [i.strip() for i in open("users.txt", "r").readlines() if not str(i).startswith("#")]
loaded_tokens = [f"{index2};{i.strip()}" for index2, i in enumerate(open("tokens.txt", "r").readlines()) if not str(i).startswith("#")]
listeners_tokens = [f"L;{i.strip()}" for i in open("listener_tokens.txt", "r").readlines() if not str(i).startswith("#")]
liker_tokens = [f"L2;{i.strip()}" for i in open("liker_token.txt", "r").readlines() if not str(i).startswith("#")]
comment_tokens = [f"C2;{i.strip()}" for i in open("comment_scan_tokens.txt", "r").readlines() if not str(i).startswith("#")]
comment_reply_tokens = [f"C3;{i.strip()}" for i in open("comment_reply_tokens.txt", "r").readlines() if not str(i).startswith("#")]
reply_own_comments_token = [f"C4;{i.strip()}" for i in open("reply_own_comment_tokens.txt", "r").readlines() if not str(i).startswith("#")]
loaded_tokens.extend(listeners_tokens)
loaded_tokens.extend(liker_tokens)
loaded_tokens.extend(comment_tokens)
loaded_tokens.extend(comment_reply_tokens)
loaded_tokens.extend(reply_own_comments_token)
WAIT_FOR_TOP_COMMENT = int(input("[Input] How many seconds you want to looking for TOP Comment : "))
COMMENT_ON_OWN_REPLY = input("[Input] Do you want to post comment on comments posted by your own clients (Y/N) : ")
if COMMENT_ON_OWN_REPLY.lower() == "y":
    COMMENT_ON_OWN_REPLY = True
    COMMENT_ON_OWN_REPLY_CLIENTS_COUNT = int("[Input] How many clients you want to use for replying to own comments : ")
else:
    COMMENT_ON_OWN_REPLY = False
IS_SEQUENCE = True
COMMENT_TOKEN_INTERVAL = 60
SEND_IMAGE = input("[Input] Do you want to send Image with comment (Y/N): ")
SEND_IMAGE = True if SEND_IMAGE.lower() == "y" else False


num_threads = int(input("[Input] How many threads you want to create at a time for logging in : "))
while loaded_tokens:
    threads = []
    for _ in range(num_threads):
        if loaded_tokens:
            token = loaded_tokens.pop(0)
            thread = threading.Thread(target=utils.create_client, args=(token, SESSIONS_DIRECTORY,))
            thread.start()
            threads.append(thread)

    for thread in threads:
        thread.join()

CACHE = utils.CACHE
COMMENT_SCANNERS = utils.resolve_scanner_time(CACHE['commenters'], COMMENT_TOKEN_INTERVAL)
WORKING_LISTENER = CACHE['listeners'][0]
list_members = []
rep = input("[Input] Do you want to follow users and enable notifications (U for users.txt/ L for List / N for No) : ")
if rep.lower() == "l":
    WORKING_LISTS = utils.get_or_create_list(CACHE['likers'][0], LIST_NAME, LIST_ID)
    print(f"[Twitter] [Got Lists] {WORKING_LISTS}")
    print("\r[Twitter] Getting List Members", end="")
    for _list in WORKING_LISTS:
        for _, members in WORKING_LISTENER.iter_list_member(WORKING_LISTS, pages=30, wait_time=(1, 3)):
            list_members.extend([member for member in members])
            print(f"\r[Twitter] Getting List Members ..{len(list_members)}", end="")
        print(f"\r[Twitter] Got List Members ........{len(list_members)}\t\t")
elif rep.lower() == "u":
    print("\r[Twitter] Getting Users from users.txt")
    with open("users.txt", "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()
        for line in lines:
            list_members.append(line.strip().split(","))
            # try:
            #     print(f"\r[Twitter] Getting User : {username}", end="")
            #     user = utils.Twitter("test").get_user_info(username)
            #     list_members.append(user)
            #     print(f"\r[Twitter] Got User : {user}\t\t")
            # except Exception as UError:
            #     print(f"\r[Twitter] [{username}] Error while getting user : {UError}\t\t")
    print(f"\r[Twitter] Got Users from users.txt ........{len(list_members)}\t\t")

if list_members:
    print("[Twitter] Following Users")
    for member in list_members:
        username = member.username if hasattr(member, "username") else member[0]
        user_id = member.id if hasattr(member, "id") else member[1]
        try:
            print(f"\r[Twitter] Following User : {username}", end="")
            WORKING_LISTENER.follow_user(user_id)
            print(f"\r[Twitter] Enabling Notifications : {username}", end="")
            WORKING_LISTENER.enable_notifications(user_id)
        except Exception as FError:
            print("\r")
            print(f"[Twitter] [{username}] Error Occurred while Following User : {FError}", file=sys.stderr)
        time.sleep(20)

WAIT_TIME = input(f"[Input] Enter the Number of seconds you want to wait before sending comment : ")
WAIT_TIME = int(WAIT_TIME)

IS_SEQUENCE_CLIENT = input(f"[Input] Do you want Clients to Work in Sequence (Y/N): ")
if IS_SEQUENCE_CLIENT.lower().strip() == "y":
    CLIENT_INTERVAL = int(input(f"[Input] How many seconds of interval you want to add in next client use (set it to 0 to turn it off): "))
    IS_SEQUENCE_CLIENT = True
else:
    CLIENT_INTERVAL = 0
    IS_SEQUENCE_CLIENT = False
    response = input(f"[Input] We have {len(CACHE['clients'])} Clients logged In. How many do you want to use for comment: ")
    if not str(response).isdigit() or int(response) > len(CACHE['clients']) or str(response) == "0":
        print(f"[System] [Bad Request] You haven't enter a Valid Number , using All {len(CACHE['clients'])} clients")
        WRITER_CLIENTS = len(CACHE['clients'])
    else:
        WRITER_CLIENTS = int(response)
        print(f"[System] [Success] Randomly Selected {response} clients")

response = input(f"[Input] We have {len(CACHE['likers'])} Liker logged In. How many do you want to use for like: ")
if not str(response).isdigit() or int(response) > len(CACHE['likers']) or str(response) == "0":
    print(f"[System] [Bad Request] You haven't enter a Valid Number , using All {len(CACHE['likers'])} Liker")
    LIKERS = len(CACHE['likers'])
else:
    LIKERS = int(response)
    print(f"[System] [Success] Randomly Selected {response} Liker")

LIKE_COMMENTS = input("Do you want to 'Like' the commented tweets too? (Y/N)")
if LIKE_COMMENTS.lower() == "y":
    LIKE_COMMENTS = True
else:
    LIKE_COMMENTS = False

USE_SEPARATE_COMMENTS = input("Do you want to Separate Comments for All Clients? (Y/N) ")
if USE_SEPARATE_COMMENTS.lower() == "y":
    USE_SEPARATE_COMMENTS = True
else:
    USE_SEPARATE_COMMENTS = False

print("[Twitter] Waiting for Tweets")


def get_new_client(new=False):
    global LAST_CLIENT, CLIENTS_LAST_TWEET
    all_clients = CACHE['clients']
    if new:
        next_client_index = LAST_CLIENT + 1
    else:
        next_client_index = LAST_CLIENT
    try:
        new_client = all_clients[next_client_index]
        LAST_CLIENT = next_client_index
    except:
        next_client_index = 0
        new_client = all_clients[next_client_index]
        LAST_CLIENT = next_client_index

    current_time = datetime.datetime.utcnow().timestamp()

    if CLIENTS_LAST_TWEET.get(new_client.me.id) and CLIENT_INTERVAL != 0:
        previous_time = CLIENTS_LAST_TWEET[new_client.me.id]
        if current_time - previous_time >= CLIENT_INTERVAL:
            CLIENTS_LAST_TWEET[new_client.me.id] = current_time
            return new_client
        else:
            return None
    elif not CLIENTS_LAST_TWEET.get(new_client.me.id) and CLIENT_INTERVAL != 0:
        CLIENTS_LAST_TWEET[new_client.me.id] = current_time
        return new_client

    return new_client


def like_tweet(_tweet, _client):
    if str(_tweet).isdigit():
        tweet_id = _tweet
    else:
        tweet_id = _tweet.id
    try:
        _client.like_tweet(tweet_id)
        print(f"[Twitter] [User={_client.me.id}] [Success] [Tweet ID={tweet_id}] Like has been posted")
    except Exception as e3:
        print(f"[Twitter] [User={_client.me.id}] [Error] [Tweet ID={tweet_id}] Like couldn't be posted : {str(e3)}")


def send_tweet(target_tweet, _client_):
    shuffled_liker = random.sample(CACHE['likers'], LIKERS)
    try:
        # client_index = utils.get_client_index(CACHE['clients'], _client_)
        client_index = CACHE['clients'].index(_client_)
        print(f"[System] [{_client_.me.username}] Client Index is : {client_index + 1}")
        comments = utils.get_client_comment(client_index)
        if not USE_SEPARATE_COMMENTS or not comments:
            print(f"[System] [{_client_.me.username}] Fallback to comments.txt")
            comments = COMMENTS
        print(f"[Twitter] [Waiting] [User={_client_.me.id}] [Tweet ID={target_tweet.id}] Waiting for {WAIT_TIME} seconds before sending comments")
        time.sleep(WAIT_TIME)
        comment_to_send = random.choice(comments)
        if len(comment_to_send) == 2 and SEND_IMAGE:
            imageLink = os.path.join(IMAGES_DIRECTORY, comment_to_send[1].strip())
            new_tweet_id = _client_.create_tweet(comment_to_send[0].strip(), media=imageLink, reply_to=target_tweet.id)
        else:
            new_tweet_id = _client_.create_tweet(comment_to_send[0], reply_to=target_tweet.id)
        print(f"[Twitter] [User={_client_.me.id}] [Success] [Tweet ID={target_tweet.id}] [Replied Tweet ID={new_tweet_id}] Tweet has been replied")
        _threads = []
        if LIKE_COMMENTS:
            for liker in shuffled_liker:
                n = threading.Thread(target=like_tweet, args=(new_tweet_id, liker))
                _threads.append(n)
                n.start()

        if COMMENT_ON_OWN_REPLY:
            shuffled_commenters = random.sample(CACHE['reply_own_comment_token'], 2)
            for client in shuffled_commenters:
                comment_to_send = random.choice(COMMENTS)
                if len(comment_to_send) == 2 and SEND_IMAGE:
                    imageLink = os.path.join(IMAGES_DIRECTORY, comment_to_send[1].strip())
                    new_reply_id = client.create_tweet(comment_to_send[0].strip(), media=imageLink, reply_to=new_tweet_id)
                else:
                    new_reply_id = client.create_tweet(comment_to_send[0], reply_to=new_tweet_id)
                print(f"[Twitter] [User={_client_.me.id}] [Success] [Comment Tweet ID={new_tweet_id}] [Replied Tweet ID={new_reply_id}] Comment has been replied")

        for _ in _threads:
            _.join()

    except Exception as e2:
        traceback.print_exc()
        print(f"[Twitter] [User={_client_.me.id}] [Error] [Tweet ID={target_tweet.id}] Tweet couldn't be replied : {str(e2)}")


def contains_url(input_string):
    url_pattern = r'https?://\S+|www\.\S+'

    if re.search(url_pattern, input_string):
        return True

    return False


def wait_for_top_comment(_tweet):
    global comments_done, COMMENT_SCANNERS
    time.sleep(1)
    first = True
    start_time = datetime.datetime.now().timestamp()
    end_time = start_time + WAIT_FOR_TOP_COMMENT
    while start_time < end_time:
        try:
            if IS_SEQUENCE:
                comment_listener = utils.get_scanner(COMMENT_SCANNERS)
                if not comment_listener:
                    COMMENT_SCANNERS = utils.resolve_scanner_time(CACHE['commenters'], COMMENT_TOKEN_INTERVAL)
                    comment_listener = utils.get_scanner(COMMENT_SCANNERS)

                _tweet = comment_listener.tweet_detail(_tweet.id)
            print(f"[Twitter] [Scanning] For comments using : {_tweet._client.me.username}")

            _, comments, _ = _tweet._get_comments(response=None, cursor=None)

            if comments:
                comments[0][-1].expand()
                for comment in comments[0][-1].tweets:
                    if str(comment.author.id) in [str(i.me.id) for i in CACHE['clients_reply_comment']]:
                        continue

                if len(comments[0][-1].tweets) != 0:
                    _ = comments[0][-1].tweets[0]

                    client = random.choice(CACHE['clients_reply_comment'])
                    if str(_.id) not in comments_done and not contains_url(_.text) and str(_.author.id) not in [str(i.me.id) for i in CACHE['clients_reply_comment']]:
                        comments_done.append(str(_.id))
                        try:
                            comment_to_send = random.choice(COMMENTS)
                            if len(comment_to_send) == 2 and SEND_IMAGE:
                                imageLink = os.path.join(IMAGES_DIRECTORY, comment_to_send[1].strip())
                                new_tweet_id = client.create_tweet(comment_to_send[0].strip(), media=imageLink, reply_to=_.id)
                            else:
                                new_tweet_id = client.create_tweet(comment_to_send[0], reply_to=_.id)

                            print(f"[Twitter] [User={client.me.id}] [Success] [Comment ID={_tweet.id}] [Replied Comment ID={new_tweet_id}] Tweet has been sent in reply to Comment")
                            if LIKE_COMMENTS:
                                _threads = []
                                for liker in random.sample(CACHE['likers'], LIKERS):
                                    n = threading.Thread(target=like_tweet, args=(new_tweet_id, liker))
                                    _threads.append(n)
                                    n.start()
                                for _ in _threads:
                                    _.join()
                        except Exception as e10:
                            print(f"[Twitter] [User={client.me.id}] [Failed] [Comment ID={_tweet.id}] Tweet has not been sent in reply to Comment : {str(e10)}")
        except Exception as comment_error:
            print(f"[Twitter] [Error] Error While Checking for Comments : {str(comment_error)}")
            pass
        start_time = datetime.datetime.now().timestamp()
        if first:
            time.sleep(int(WAIT_FOR_TOP_COMMENT) / 2)
        else:
            time.sleep(random.randint(10, 15))


def get_timeout_time(timeout_seconds=300):
    return utils.get_current_time(True) + timeout_seconds


def get_listener(_username_):
    for _index_, _listener_ in enumerate(CACHE['listeners']):
        if _listener_.me.username == _username_:
            return _index_, _listener_
    return None, None


def on_notification(obj, notification, data_message):
    persistent_id = str(data_message.persistent_id)
    _notification = GetNotification().from_json(notification)
    if not _notification:
        return

    _username_ = _notification.recipient.username
    _index_, _listener_ = get_listener(_username_)

    if not _listener_:
        return

    if persistent_id in _listener_.received_persistent_ids:
        return

    CACHE['listeners'][_index_].received_persistent_ids.append(str(persistent_id))
    utils.save_persistent_id(persistent_id, _listener_.persistent_id_filename)
    if isinstance(_notification, NewTweet):
        author = _notification.author
        _tweet = _notification.tweet
        proxy = CACHE['listeners'][0].proxy
        tweet = Twitter("test", proxy=proxy).tweet_detail(str(_tweet.id))
        print(tweet)
        if not tweet.is_retweet and not tweet.is_reply:
            print(f"[Twitter] [Success] [New Tweet] New Tweet from User={author.username} , (Tweet ID={tweet.id})")
            if IS_SEQUENCE_CLIENT:
                _ = get_new_client(True)
                if _:
                    this_client = [_]
                else:
                    this_client = []
            else:
                this_client = random.sample(CACHE['clients'], WRITER_CLIENTS)

            for _client_ in this_client:
                threading.Thread(target=send_tweet, args=(tweet, _client_)).start()

            if int(WAIT_FOR_TOP_COMMENT) != 0:
                threading.Thread(target=wait_for_top_comment, args=(tweet,)).start()


def listener_func(_fcm_token_, on_notification_callback, received_persistent_ids):
    return listen(_fcm_token_, on_notification_callback, received_persistent_ids)


# if __name__ == "__main__":
#
#     for index, listener in enumerate(CACHE['listeners']):
#         creds = utils.get_fcm_credentials(listener.me.username)
#         CACHE['listeners'][index].fcm = creds
#         CACHE['listeners'][index].persistent_id_filename = f"{listener.me.username}.{utils.PERSISTENT_ID_FILENAME}"
#         CACHE['listeners'][index].received_persistent_ids = utils.get_persistent_id(CACHE['listeners'][index].persistent_id_filename)
#         fcm_token = creds["fcm"]["token"]
#         response = listener.set_notifications(fcm_token)
#         print(f"[Twitter] [{listener.me.username}] Registration Response : {response}")
#
#     try:
#         while True:
#             for index, listener in enumerate(CACHE['listeners']):
#                 if not listener.thread or not listener.thread.is_alive():
#                     print(f"[System] Starting listener for {listener.me.username}")
#                     t = threading.Thread(target=listener_func, args=(listener.fcm, on_notification, listener.received_persistent_ids))
#                     CACHE['listeners'][index].thread, CACHE['listeners'][index].thread_timeout = t, get_timeout_time()
#                     t.daemon = True
#                     t.start()
#                     print("[Twitter] Waiting for New Tweet\n--> Press Ctrl+C to Exit")
#
#     except KeyboardInterrupt:
#         print("\r[System] Exiting..")



